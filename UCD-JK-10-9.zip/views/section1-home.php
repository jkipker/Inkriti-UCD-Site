<!-- scene 1 -->

<div class="logo-bg">
  
</div>
    <section class="sec1">
            <div id="home">
              <div class="home_wrapper">
                <a href="#home"><h1><img src="img/logo.png" alt="United Concorida Dental logo"></h1></a>
                <nav id="navbar" data-30="opacity:0" data-0="opacity:1">
                   <ul class="menu">
          			<li><div><a class="nav-lookback" href="#">A Look Back</a></div></li>
          			<li><div><a class="nav-execsummary" href="#">Executive<br>Summary</a></div></li>
          			<li><div><a class="nav-ourmission" href="#">Our Mission</a> </div>
          				<ul class="subNav">
          					<li><a class="nav-ourmission" href="#">Mission</a></li>
          					<li><a class="nav-direction" href="#">Direction</a></li>
          					<li><a class="nav-program" href="#">Program</a></li>
          				</ul>
          			</li>
          			<li><div><a class="nav-ourcommunity" href="#">Community</a></div></li>
          			<li><div><a class="nav-financials" href="#">Financials</a></div></li>
          			<li><div><a class="nav-company" href="#">Company</a></div></li>
                   </ul>
                </nav>
              </div>
            </div>
    </section>

    <!--secondary nav-->

            <div id="home" class="nav2">
                <nav id="navbar" class="bottom-nav">
                  <img class="nav-logo-btm" src="img/logo-btm-nav.png"/>
                   <ul class="menu">
                <li><div><a class="nav-home" href="#" data-target="lookBack">Home <hr/></a></div></li>
                <li><div><a class="nav-lookback" href="#" data-target="lookBack">A Look Back <hr/></a></div></li>
                <li><div><a class="nav-execsummary" href="#" data-target="exeSummary">Executive<br>Summary <hr/></a></div></li>
                <li><div><a class="nav-ourmission" href="#" data-target="ourMission">Our Mission <hr/></a> </div>
                  <ul class="subNav">
                    <li><a class="nav-ourmission" href="#" data-target="tab1">Mission</a></li>
                    <li><a class="nav-direction" href="#" data-target="tab2">Direction</a></li>
                    <li><a class="nav-program" href="#" data-target="tab3">Program</a></li>
                  </ul>
                </li>
                <li><div><a class="nav-ourcommunity" href="#" data-target="ourCommunity">Community <hr/></a></div></li>
                <li><div><a class="nav-financials" href="#" data-target="financials">Financials <hr/></a></div></li>
                <li><div><a class="nav-company" href="#" data-target="ourCompany">Company <hr/></a></div></li>
                   </ul>
                   
                </nav>
            </div>